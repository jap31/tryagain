package pos2 ;
import java.util.*;


public class main1 {
	static Scanner scan = new Scanner (System.in);
	public static void main(String[] args) {
		
		array arr = new array();
		
		System.out.println(arr.prod1);
		

	}

}

